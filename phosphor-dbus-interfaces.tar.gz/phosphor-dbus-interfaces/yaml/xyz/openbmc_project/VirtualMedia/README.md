# Virtual Media

All exposed objects, their paths and interfaces are described
in [openbmc/docs/designs/VirtualMedia.md](https://github.com/openbmc/docs/blob/master/designs/VirtualMedia.md).